MUGEN SFF 大ポトレ・小ポトレ GIF Extractor
==================================================

【概要】

SFF v1.0.1 ファイルから、Group 9000 のポートレート画像を
GIF 形式で抽出する Windows 向けツールです。


【主な機能】

・Group 9000 / Image 0（小ポトレ）の抽出
・Group 9000 / Image 1（大ポトレ）の抽出
・対象画像のウィンドウ内プレビュー
・同じ Group / Image 番号の画像が複数ある場合、すべて個別の GIF として保存
・抽出処理中もウィンドウが応答するバックグラウンド処理
・一部の不完全な PCX RLE データについて、可能な範囲で読み取り・補完を試行
・元の SFF ファイルを変更せずに抽出


【動作環境】

・Windows 10 / Windows 11 を想定
・対応形式：MUGEN SFF v1.0.1

※ SFF v2 など、異なる形式のファイルには対応していません。


【使い方】

1. MUGEN_SFF_Extractor.exe を起動します。
2. 「参照」ボタンで SFF ファイルを選択するか、SFF ファイルをウィンドウにドラッグ＆ドロップします。
3. プレビューで小ポトレ・大ポトレを確認します。
4. 「抽出を開始」ボタンを押します。
5. 完了メッセージに表示される出力先フォルダーを確認します。


【抽出対象】

Group 9000 / Image 0
　内容：小ポトレ
　出力例：group9000_image0_01.gif

Group 9000 / Image 1
　内容：大ポトレ
　出力例：group9000_image1_01.gif

同じ Group / Image 番号の画像が複数ある場合は、
_01、_02、_03 のように連番で保存されます。


【保存先】

選択した SFF ファイルと同じフォルダー内に、
次の名前のフォルダーを作成して GIF を保存します。

フォルダー名：＜SFFファイル名＞_9000_GIF

例：kfm.sff の場合
保存先：kfm_9000_GIF フォルダー


【エラー・注意事項】

・SFF 内の画像データやパレット情報が欠損している場合、プレビューや GIF 抽出に失敗したり、画像が崩れたりすることがあります。

・一部の不完全な PCX RLE データは読み取り・補完を試みますが、元データに存在しない情報を完全に復元することはできません。

・GIF の透明色の扱いなどにより、元画像と表示結果が異なる場合があります。

・使用前に、元の SFF ファイルのバックアップを取ることをおすすめします。

・本ツールは、すべての SFF ファイルでの動作を保証するものではありません。


【権利・再配布について】

本ツールで抽出した画像やキャラクター素材の利用・再配布については、それぞれの権利者が定める利用条件に従ってください。

本ツール自体の再配布・改変については、配布元が明示する利用条件に従ってください。また、同梱ライブラリについては、それぞれのライセンス条件を確認してください。


【不具合報告】

不具合を報告する際は、次の情報を添えてください。

・Windows のバージョン
・表示されたエラーメッセージ全文
・不具合が発生した操作


【ライセンス・著作権表示】

本ツールには、以下のソフトウェアおよびライブラリを使用しています。
各ソフトウェアの著作権表示、ライセンス条件および免責事項については、同梱のライセンスファイルまたは各公式ページをご確認ください。


■ Python

使用バージョン：Python 3.13.2
ライセンスファイル：LICENS\LICENSE(Python).txt
公式ページ：
https://github.com/python/cpython/blob/v3.13.2/LICENSE


■ Tcl

使用バージョン：Tcl 8.6 系
ライセンスファイル：LICENS\LICENSE(tcl).txt
公式ページ：
https://github.com/tcltk/tcl/blob/main/license.terms


■ Tk

使用バージョン：Tk 8.6 系
ライセンスファイル：LICENS\LICENSE(Tk).txt
公式ページ：
https://github.com/tcltk/tk/blob/main/license.terms


■ Pillow

使用バージョン：Pillow 11.1.0
ライセンスファイル：LICENS\LICENSE(Pillow).txt
公式ページ：
https://github.com/python-pillow/Pillow/blob/11.1.0/LICENSE


■ tkinterdnd2

使用バージョン：tkinterdnd2 0.4.2
ライセンスファイル：LICENS\LICENSE(tkinterdnd2).txt
公式ページ：
https://github.com/pmgagne/tkinterdnd2/blob/master/LICENSE


■ TkDND

tkinterdnd2 に同梱される TkDND 拡張を使用しています。
ライセンスファイル：LICENS\LICENSE(TkDND).txt
公式ページ：
https://github.com/petasis/tkdnd/blob/master/license.terms


■ PyInstaller

使用バージョン：PyInstaller 6.22.3
ライセンスファイル：LICENS\LICENSE(PyInstaller).txt
公式ページ：
https://github.com/pyinstaller/pyinstaller/blob/v6.22.3/COPYING.txt


==================================================
